#include<iostream>
#include<conio.h>
#include<fstream>
#include<string.h>
#include<cstdlib>
using namespace std;

class MU_Hostel{
public:

    virtual void display(){
        cout<<" Three Hostel are operational "<<endl;
        cout<<" 1.WING -A \n 2. WING - B \n 3. WING - C"<<endl;
        cout<<"Chief Warden"<<endl;
        cout<<"Dr. RAJESH PATEL"<<endl;
        cout<<"Contact No : 9099095048"<<endl;
        cout<<"Location : MA555"<<endl;
    }
    void medical(){
        cout<<"Medical Emergency Contact"<<endl;
        cout<<"1.Mr. Dharmrajsinh Jadeja"<<endl<<" 9099939575 "<< endl<<" From 10.00 AM to 10.00 PM" <<endl;
        cout<<"1.Mr. Latif Kargathra"<<endl<<" 9099939572 "<< endl<<" From 10.00 PM to 07.00 AM" <<endl;
        cout<<"1.Mr. Kishan Parakara "<<endl<<" 9099939556 "<< endl<<" From 07.00 AM to 10.00 AM" <<endl;
    }
    virtual void capacity(){
    }

};

class Hostel_A : public MU_Hostel{
public:

    void display(){
        cout<<" Wing - A  "<<endl;
        cout<<" Girls Hostel "<<endl;
        cout<<"Warden : Rupali Pandya"<<"Contact No : 9727724692"<<endl<<" Megha  "<<endl<<"Contact No: 7573012805 "<<endl;
    }
    void capacity(){
        cout<<" Floor >> G+11 "<<endl;
        cout<<" Room >> 157"<<endl;
        cout<<" Capacity >> 693"<<endl;
    }
};

class Hostel_B : public MU_Hostel{
public:

    void display(){
        cout<<" Wing - B "<<endl;
        cout<<" Boys Hostel "<<endl;
        cout<<" Warden : Visashwar Singh"<<endl;
        cout<<" Contact No : 9099939547"<<endl;
    }
    void capacity(){
        cout<<"Floor >> G+11"<<endl;
        cout<<"Room >> 153"<<endl;
        cout<<"Capacity >> 587"<<endl;
    }
};

class Hostel_C : public MU_Hostel {
public:

    void display(){
        cout<<" Wing - C "<<endl;
        cout<< " Boys Hostel "<<endl;
        cout<<" Warden : Amulyakumar Shaho "<<endl;
        cout<<" Contact No : 9687680249"<<endl;
    }
    void capacity(){
        cout<<" Floor >> G+11 "<<endl;
        cout<<" Room >> 280"<<endl;
        cout<<" Capacity >> 1131"<<endl;
    }

};

class Hostel_officer{
    char name[30], dept_name[30], room_no[30], blood_group[10], address[100],country[20], guardin_name[30], grd_occup[30], gr_no[10], enroll_no[20], mobile_no[15], pincode[10], road_no[15], grd_mobileno[15], student_type[20];
public:
    void hostel_admission(){
        cout<<" ::::::: Admission process ::::::: "<<endl;
        cout<<"Enter the name of students : "<<endl;
        cin>>name;
        cout<<"Enter the gr number for the students : "<<endl;
        cin>>gr_no;
        cout<<"Enter the student type : "<<endl;
        cin>>student_type;
        cout<<"Enter the department name"<<endl;
        cin>>dept_name;
        cout<<"Enter the room no alloted to the students : "<<endl;
        cin>>room_no;
        cout<<"Enter the mobile number of students"<<endl;
        cin>>mobile_no;
        cout<<"Enter the blood group"<<endl;
        cin>>blood_group;
        cout<<"_____________Address Information______________"<<endl;
        cout<<"Enter the country name : "<<endl;
        cin>>country;
        cout<<"Enter the address"<<endl;
        cin>>address;
        cout<<"Enter the pin code"<<endl;
        cin>>pincode;
        cout<<"Enter the road no"<<endl;
        cin>>road_no;
        cout<<"_____________Guardian Information______________"<<endl;
        cout<<"Enter the guardian name"<<endl;
        cin>>guardin_name;
        cout<<"Enter the guardian occupation"<<endl;
        cin>>grd_occup;
        cout<<"Enter the mobile number of guardian"<<endl;
        cin>>grd_mobileno;
        }


    void displaystudent(){
        cout<<"::::::::::::Student information::::::::::"<<endl;
        cout<<"Student name : "<<name<<endl;
        cout<<"Student GR no : "<<gr_no<<endl;
        cout<<"Department : "<<dept_name<<endl;
        cout<<"Room NO : "<<room_no<<endl;
        cout<<"Mobile No : "<<mobile_no<<endl;
        cout<<"Blood Group : "<<blood_group<<endl;
        cout<<"The address details of students"<<endl;
        cout<<"COUNTRY : "<<country<<endl;
        cout<<"ADDRESS : "<<address<<endl;
        cout<<"PIN CODE : "<<pincode<<endl;
        cout<<"ROAD NO : "<<road_no<<endl;
        cout<<"Guardian details : "<<endl;
        cout<<"Guardian name : "<<guardin_name<<endl;
        cout<<"Occupation : "<<grd_occup<<endl;
        cout<<"Mobile NO : "<<grd_mobileno<<endl;

    }

    void grno1(){
        cout<<"The GR No is : "<<gr_no<<endl;
    }

    void name1(){
        cout<<"The Name is : "<<name<<endl;
    }
    char *getname(){
        return name;
    }
    char *getgrno(){
        return gr_no;
    }
    void update(char *grno, char *rmno){
        strcpy(gr_no, grno);
        strcpy(room_no, rmno);
    }
};

class log_in{
    //File handling for password , user name, Role Student, Hostel Officer, Admin
protected:
    char username[50];
    char password[50];
    unsigned int role;
public:
    void Register(){
        ofstream fs("login.txt", ios::app);
        cout<<"Enter username : "<<endl;
        cin>>username;
        cout<<"Enter password : "<<endl;
        cin>>password;
        cout <<"Press the below option"<<endl<<" 1.Student"<<endl<<"2.Hostel Officer"<<endl;
        cin>>role;
        fs<<username<<" "<<password<<" "<<role<<" ";
        fs.close();
    }
    void login(char user_name[], char pass_word[]){
        ifstream fs("login.txt", ios::in);
        while(!fs.eof()){
            fs>>username>>password>>role;
            if(strcmp(user_name, this-> username) ==0 && strcmp(pass_word, this->password)==0){
                if(role == 1){
                    int choose, ch;
                    cout<<"Welcome to student : "<<username<<endl;
                    MU_Hostel MU;
                    Hostel_A MA;
                    Hostel_B MB;
                    Hostel_C MC;
                    MU_Hostel *muptr;

                    while(ch){
                            cout<<"Please choose your option : "<<endl;
                            cout<<" 1. Hostel Information"<<endl;
                            cout<<" 2. Wing - A information "<<endl;
                            cout<<" 3. Wing - B information "<<endl;
                            cout<<" 4. Wing - C information "<<endl;
                            cout<<" 5. Emergency Medical Contact "<<endl;
                            cin>>choose;
                        switch(choose){
                        case 1:
                            muptr =&MU;
                            muptr ->display();
                            break;
                        case 2:
                            muptr =&MA;
                            muptr ->display();
                            muptr ->capacity();
                            break;
                        case 3:
                            muptr =&MB;
                            muptr -> display();
                            muptr -> capacity();
                            break;
                        case 4:
                            muptr =&MC;
                            muptr -> display();
                            muptr -> capacity();
                            break;
                        case 5:
                            muptr =&MU;
                            muptr ->medical();
                            break;
                        }
                        cout<<"Do want to you continue ? (Y:1/N:0)"<<endl;
                        cin>>ch;

                    }


                }
                else if(role == 2){
                    cout<<"Welcome to Hostel officer : "<<username<<endl;
                    Hostel_officer rec;
                    fstream file;
                    file.open("admission.txt", ios::ate | ios::in | ios::out | ios :: binary);
                    char c, ch, nm[30], grno[10], rmno[30];
                    int choice, cnt, found = 0;
                    while(c){
                        cout<<" **** MU Hostel ***** "<<endl;
                        cout<<" 1. Admission of new students in Hostel "<<endl;
                        cout<<" 2. Display All students record "<<endl;
                        cout<<" 3. Search GR No "<<endl;
                        cout<<" 4. Search Student Name "<<endl;
                        cout<<" 5. Update  Room No "<<endl;
                        cin>>choice;
                        switch(choice){
                        case 1:
                            rec.hostel_admission();
                            file.write((char *)&rec, sizeof(rec));
                            cout<<"Admission Done successfully"<<endl;
                            break;
                        case 2:
                            file.seekg(0, ios::beg);
                            cout<<"Records in Hostel "<<endl;
                            while(file){
                                file.read((char *)&rec, sizeof(rec));
                                if(!file.eof()){
                                    rec.displaystudent();
                                }
                            }
                            file.clear();
                            break;
                        case 3:
                            cout<<"Enter name : "<<endl;
                            cin>>nm;
                            file.seekg(0, ios::beg);
                            found = 0;
                            while(file.read((char *)&rec, sizeof(rec))){
                                if(strcmp(nm, rec.getname())== 0){
                                    found = 1;
                                    rec.grno1();
                                }
                            }
                            file.clear();
                            if(found == 0){
                                cout<<" Record Not Found "<<endl;
                            }
                            break;
                        case 4:
                            cout<<"Enter GR No : "<<endl;
                            cin>>grno;
                            file.seekg(0, ios::beg);
                            found = 0;
                            while(file.read((char *) &rec, sizeof(rec))){
                                if(strcmp(grno,rec.getgrno())==0){
                                    found = 1;
                                    rec.name1();
                                }
                            }
                            file.clear();
                            if(found = 0){
                                cout<<" Record Not Found"<<endl;
                            }
                            break;
                        case 5:
                            cout<<" Enter GR no : "<<endl;
                            cin>>grno;
                            file.seekg(0, ios::beg);
                            found = 0;
                            cnt = 0;
                            while(file.read((char *) &rec , sizeof(rec))){
                                cnt++;
                                if(strcmp(grno, rec.getgrno()) == 0){
                                    found = 1;
                                    break;
                                }
                            }
                            file.clear();
                            if(found == 0){
                                cout<<" Record Not Found "<<endl;
                            }
                            else{
                                int location = (cnt - 1)* sizeof(rec);
                                cin.get(ch);
                                if(file.eof()){
                                    file.clear();
                                }
                                cout<<" Enter new Room No : "<<endl;
                                cin>>rmno;
                                file.seekp(location);
                                rec.update(grno, rmno);
                                file.write((char *) &rec, sizeof(rec));
                                file.flush();
                            }
                            break;

                        }
                        cout<<"Do you want to exit(Y : 0 /N : 1) : "<<endl;
                        cin>>c;

                    }
                    file.close();
                }
            }
        }
        fs.close();
    }
};

int main(){
    log_in l1;
    while(1){
        system("cls");
        char username[50], password[50];
        int ch,c;
        cout<<"\t\t\t\t\t\tWELCOME TO\t\t\t"<<endl;
        cout<<endl;
        cout<<"\t\t\t\t\t*****MARWADI UNIVERSITY*****\t\t"<<endl;
        cout<<endl;
        cout<<"\t\t\t\t\t*****HOSTEL MANAGEMENT*****\t\t"<<endl;
        cout<<endl;
        cout<<"1.Login\n2.Register\n3.Exit"<<endl;
        cout<<"Please the Enter the choice : "<<endl;
        cin>>ch;
        while(c){
            switch(ch){
            case 1:
                cout<<"\t\t\t-----LogIn-----"<<endl;
                cout<<" Username : "<<endl;
                cin>>username;
                cout<<" Password : "<<endl;
                cin>>password;
                l1.login(username, password);
                break;
            case 2:
                cout<<"\t\t\t-*-*-*Registration*-*-*-"<<endl;
                l1.Register();
                break;
            }
            cout<<"Do you want to continue? (Y:1/N:0)"<<endl;
            cin>>c;
        }

    }
}
